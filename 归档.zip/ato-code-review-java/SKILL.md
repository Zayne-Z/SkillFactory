---
name: ato-code-review-java
description: >-
  Java 后端增量代码检视 Skill。一个目录同时支持 VS Code Builder、opencode、Claude Code
  等运行器；主编排器读取本文件驱动全流程，并行拉起子执行器逐阶段完成检视。所有中间状态
  持久化到 .codereview/state.json，支持任意环节断点续跑。启动后若 .codereview/state.json 存在则询问续跑或重新检视；
  Phase 1 必须确认分支、检视深度、跳过低风险、是否生成 HTML、每批最大行数、是否深入分析疑问代码；
  可分多轮收集，用户跳过时应用默认值，六项全部落盘前禁止进入 Phase 2。主编排器必须通过 scripts/update-state.js 落盘 state.json，禁止仅在对话中更新进度。
---

# Java 后端代码检视 · 主编排工作流

> **本文件是 VS Code Builder、opencode、Claude Code 等运行器共用的主编排指令来源**。
> 主编排器启动后按阶段推进，通过子执行器/subagent 执行检视；
> 主编排器自身**不做**深度代码检视，只负责编排、状态管理、并行调度与故障恢复。
> **命令兼容规则：** 命令块使用跨 shell 的 `text` 示例；先将 `{SKILL_ROOT}` 与示例分支/选项替换为真实值，再在 Windows PowerShell 5.1、PowerShell 7、bash/zsh 中逐条执行。多条命令分开运行，不使用 Bash 专用串联、反斜杠续行或 POSIX-only 语法。
> **前置依赖：** 本 Skill 脚本基于 Node.js 运行时（零三方依赖，无需 `npm install`），并依赖 Git 取 diff；**推荐 Node.js 22+**。低版本只提示风险，不阻止执行。

---

## 0. 主编排启动清单（每次对话最先执行，优先于下文所有章节）

### 环境前置自检（最先执行一次，先于续跑探测）

本 Skill 全部脚本依赖 Node.js 与 Git；推荐 Node.js 22+。开始任何流程前先执行：

```text
node "{SKILL_ROOT}/scripts/check-env.js"
```

- 退出码 0 且打印 `环境检查通过` → 继续 §0.0 续跑探测。
- 退出码非 0 → **立即停止**，并按脚本输出明确告知用户：
  - 未检测到 Node：脚本无法运行，请通过公司 / 内部渠道安装或联系管理员配置后重试。
  - `GIT_REQUIRED` / 未检测到 Git：无法获取分支 diff，请通过公司 / 内部渠道安装或联系管理员配置后重试。
- Node 低于 22 时打印 `NODE_VERSION_RECOMMENDED`，继续执行；若出现运行异常再升级。
- **内网约束：** 仅检测并指出缺失项，**不提供任何外网下载链接**。

### 0.0 续跑 vs 重新检视（**仅**探测 `.codereview/state.json`）

**不探测** `codereview/`（该目录会累积多版本历史报告，与当前 run 无关）。

若 `.codereview/state.json` **存在**，在 §0.2 Phase 1 六问**之前**向用户提问（一条消息）：

```
检测到已有检视状态（.codereview/state.json），请选择：
1) 续跑 — 按 state.json 的 current_phase / review_progress 继续
2) 重新检视 — 清除过程文件（保留 memory.json），从头开始
```

- 即使 current_phase == "completed" 且报告文件存在，也必须先问续跑 / 重新检视；不得因 `synthesis.report_path` / `synthesis.html_report_path` 指向的文件存在就直接宣告检视完成
- 只有用户明确选择“续跑”后，才可在 completed 状态交付已有报告路径；选择“重新检视”时必须 reset 后从头开始
- 选 **续跑** → 读 state，按 §2.2 跳转；`current_phase === completed` 时输出 `synthesis.report_path`，**不**自动重跑
- 选 **重新检视** → **必须**执行：

```text
node "{SKILL_ROOT}/scripts/reset-run.js"
```

然后进入 §0.1（`state.json` 已重建）。

若 `state.json` **不存在** → 直接进入 §0.1。

### 0.1 读 state / 初始化

```text
node "{SKILL_ROOT}/scripts/init-memory.js"
# state 不存在时：
node "{SKILL_ROOT}/scripts/update-state.js" --init --checkpoint phase0_init
```

`init-memory.js` 确保 `.codereview/memory.json` 存在（用户可手动编辑项目规则，详见 `{SKILL_ROOT}/docs/memory-system.md`）。

### 0.2 Phase 1 六问（`user_confirmed !== true` 时**只做本步**）

**禁止**：只问分支就跑脚本 / 拉子执行器；六项未收齐或未应用默认值就进入 Phase 2。

六项不必一次性发给用户，可分多轮收集；但进入 Phase 2 前必须全部有合法值并复述确认。用户回复“跳过 / 默认 / 随便”时，按下列默认值落盘。

```
请确认本次 Java 增量检视配置（六项最终都必须有值）：

1) 分支 — BRANCH1：当前分支  BRANCH2：master
2) 检视深度 severity_mode — 默认 critical_high_only（可选 all）
3) 跳过低风险 skip_low_risk_files — 默认 true（可选 false）
4) 生成 HTML generate_html_report — 默认 true（可选 false）
5) 每批最大变动行数 max_lines_per_batch — 默认 2000
6) 疑问代码深入分析 deep_doubt_analysis — 默认 true（可选 false）
```

用户只答部分问题 → 可继续追问缺失项；用户跳过缺失项 → 应用默认值。**不得**在六项落盘前继续。

复述六项无异议后**必须**执行：

```text
node "{SKILL_ROOT}/scripts/update-state.js" --branch1 REVIEW_BRANCH --branch2 BASE_BRANCH --set review_options.severity_mode=critical_high_only --set review_options.skip_low_risk_files=true --set review_options.generate_html_report=true --set review_options.max_lines_per_batch=2000 --set review_options.deep_doubt_analysis=true --set review_options.user_confirmed=true --phase diff_analysis --checkpoint phase1_done
```

确认输出 `{"ok":true}` 且 `user_confirmed===true` 后，才进入 Phase 2。
Phase 2 脚本内置门禁：未完成 Phase 1 会报 `PHASE1_REQUIRED` 并 exit 2。

### 0.3 落盘 state（全程）

每个操作后用 `update-state.js` 写 `.codereview/state.json`（禁止只在聊天里说进度）。检查点表见 §2.6。子执行器**不写** state。

### 0.4 断点续跑

读 `current_phase` / `review_progress` 继续；**但 `user_confirmed !== true` 一律回到 §0.2**。

### 0.5 项目记忆

- 规则文件：`.codereview/memory.json`（`reset-run.js` **保留**；用户手动维护）
- Phase 5 每批次、每专家拉起**前**运行 `build-memory-context.js`，将 `MEMORY_BRIEF_PATH` 传给子执行器
- 用户说「记住 xxx」→ 主编排器建议 JSON 条目，由用户确认后写入 `memory.json`

---

## 1. Skill 目录（`{SKILL_ROOT}` = SKILL.md 所在目录）

```
{SKILL_ROOT}/
├── SKILL.md                  ← 本文件（主编排器运行时读取）
├── docs/                     ← 参考文档（子执行器自行按路径读取）
│   ├── java-standards.md
│   ├── spring-boot-reference.md
│   ├── mybatis-reference.md
│   ├── memory-system.md      ← .codereview/memory.json 说明
│   └── state-structure.md    ← state.json 字段说明
├── scripts/
│   ├── check-env.js            ← §0 环境自检（Node 推荐版本 + Git）
│   ├── assert-node-version.js  ← CLI 入口 Node 版本软警告（内部）
│   ├── detect-repo-name.js     ← 从 git 推断仓库名（报告标题/文件名）
│   ├── get-diff-files.js       ← 生成变动文件清单（可选跳过低风险类型）
│   ├── batch-processor.js    ← 智能分批
│   ├── export-batch-diffs.js ← 按批次预计算 unified diff（各专家共用）
│   ├── issue-resolver.js       ← 证据解析核心库（内部）
│   ├── resolve-report-issues.js← Phase 5.5 / Phase 7：curated → resolved + discarded
│   ├── git-line-authors.js   ← Phase 7 前：issue 行 git blame + 参与开发者
│   ├── render-report-md.js   ← Phase 7：JSON → MD（机械填充，优先于子执行器）
│   ├── render-report-html.js ← Phase 7.5：MD → HTML（机械填充，优先于子执行器）
│   ├── sync-report-signoff.js← HTML 签收 payload 回写 MD（CLI 兜底）
│   ├── init-memory.js        ← 初始化 .codereview/memory.json
│   ├── reset-run.js          ← 重新检视（保留 memory.json）
│   ├── build-memory-context.js ← Phase 5 前：按专家生成 memory brief
│   ├── update-state.js       ← 主编排器写 state.json（必用）
│   └── require-phase1.js     ← Phase 2 脚本门禁（内部引用）
├── templates/
│   ├── report-template.md    ← 最终 MD 报告模板
│   ├── report-shell.html     ← HTML 报告壳模板（Phase 7.5）
│   └── memory.json.example   ← memory.json 示例
├── vscode-main-builder.md    ← VS Code 主 Builder 的轻量启动提示词
└── prompts/                  ← 子执行器系统提示词（opencode/其它编排器按文件加载）
    ├── tech-stack-analysis.md
    ├── task-planner.md
    ├── code-scanner.md       ← core：核心静态（兼容旧文件名）
    ├── framework-reviewer.md ← spring：Spring/可靠性（兼容旧文件名）
    ├── security-reviewer.md
    ├── perf-reviewer.md      ← data：数据与性能（兼容旧文件名）
    ├── issue-curator.md      ← curator：跨专家合并 + 函数体级误报排除
    ├── fix-advisor.md
    ├── report-synthesizer.md
    └── report-html.md        ← Phase 7.5 HTML 渲染（可选）
```

**运行时生成：**

```
{项目根}/
├── .codereview/                    ← 持久化（含项目记忆）
│   ├── memory.json                 ← ★ 项目规则（reset-run 保留）
│   ├── state.json                  ← 全程状态（断点核心）
│   ├── memory-brief-*.json         ← Phase 5 运行时 brief（reset 清除）
│   ├── diffs/                      ← 各批次 *.patch（预计算 diff，Phase 2 生成）
│   ├── file-inventory.json
│   ├── tech-stack.json
│   ├── task-plan.json
│   ├── line-authors.json           ← Phase 7 git-line-authors.js 产出（提交人映射）
│   ├── resolved-issues.json        ← Phase 7 全量证据解析（报告唯一问题源）
│   ├── discarded-issues.json       ← 无法定位/重复 source_key 等诊断
│   └── results/                    ← 各专家 JSON；含 {batch}-resolved.json
└── codereview/                     ← 多版本交付物归档（不参与启动探测）
    ├── report_<repo>_<branch>_<date>.md
    └── report_<repo>_<branch>_<date>.html   ← 仅当 generate_html_report 为 true
```

---

## 2. 核心机制：断点续跑与故障恢复

### 2.1 状态驱动

**每个操作前读 `state.json`，每个操作后立即写回磁盘。** 字段详见 `{SKILL_ROOT}/docs/state-structure.md`。

> **所有运行器硬性要求**：主编排器**必须**用 shell 执行 `node "{SKILL_ROOT}/scripts/update-state.js" ...` 更新状态（或等价地 Write 整个 `.codereview/state.json`）。**禁止**仅在聊天里说「已进入 reviewing / 某专家已完成」而不写文件；用户应以磁盘上的 `state.json` 的 `updated_at` 与 `last_checkpoint` 为准。

关键字段：
- `current_phase`：当前大阶段（`branch_selection` → `diff_analysis` → `tech_stack` → `task_planning` → `reviewing` → `synthesizing` → `html_rendering`（可选）→ `completed`）
- `review_progress.{batch-NNN}.{expert}`：`pending` / `in_progress` / `completed` / `skipped` / `failed`

### 2.2 主编排器启动逻辑（每次对话开头必执行）

```
1. 确认 {SKILL_ROOT} 绝对路径（读取本 SKILL.md 的目录）
2. 若 .codereview/state.json 存在 → 执行 §0.0（续跑 / 重新检视）；不存在 → §0.1 init
3. 读取 .codereview/state.json（§0.0 已让用户二选一；下列跳转仅在用户选「续跑」时执行，选「重新检视」则先 reset 再从头）
   ├─ 不存在 → 进入 Phase 0（初始化）
   └─ 存在   → 读取 current_phase
       ├─ completed     → 经用户选「续跑」后，按 synthesis.html_status 三态输出报告路径（见 Phase 7 / 7.5 完成后说明）；**严禁**未经用户选择就凭报告文件存在直接宣告完成
       └─ 其它          → 跳转到对应 Phase 继续
4. 兼容性补丁：
   a. 若 state.json 不含 review_options 字段
      → 补入默认值 { "severity_mode": "critical_high_only", "skip_low_risk_files": true, "generate_html_report": true, "max_lines_per_batch": 2000, "deep_doubt_analysis": true }
   b. 若 review_options 缺少 generate_html_report → 补 true（**仅字段占位**；不得据此跳过 Phase 1 向用户提问）
   c. 若 review_options 缺少 max_lines_per_batch → 补 2000
   d. 若 review_options 缺少 user_confirmed → 补 false（为 false 时必须执行完整 Phase 1 清单）
   e. 若 synthesis 缺少 html_report_path / html_status → 补 "" 与 "skipped"
   f. 若 review_progress[*] 缺少 curator 键（升级到含 issue-curator 的版本）
      → 对每个批次补入 curator: "pending"，position 在 data 与 fix 之间
   → 写回 state.json（保证后续阶段可安全读取）
5. 若 current_phase == "branch_selection" 或 review_options.user_confirmed !== true：
   → **不得**进入 Phase 2；执行 Phase 1 清单（见 §3 Phase 1），收齐并复述后再写 state
6. 对 reviewing 阶段：按批次、按专家顺序（见 Phase 5）扫描 review_progress，
   找到第一个 status 为 pending 或 in_progress 的 {batch}+{expert}（completed / skipped / failed 跳过；
   in_progress 时先按 docs/state-structure.md「in_progress 防死锁」校验结果 JSON，再决定 completed 或改 pending 重跑）
7. 对 synthesizing 阶段：若 synthesis.report_path 的 MD 已存在且非空
   ├─ generate_html_report === true  → current_phase = "html_rendering"，进入步骤 5b
   └─ 否则 → synthesis.html_status = "skipped"，current_phase = "completed"
   若 MD 不存在 → 重跑 Phase 7 报告合成
5b. 对 html_rendering 阶段：先跑 render-report-html.js，再按 docs/state-structure.md「HTML 完整性校验」检查 html_report_path
   ├─ 通过 → html_status = completed，current_phase = completed
   └─ 不通过 → 重跑脚本或重拉 java-codereview-report-html（最多 2 次；仍失败 → html_status = failed，current_phase = completed，MD 仍交付）
6. 幂等（可选）：tech_stack 且 tech-stack.json 已合法 → 可直接进入 task_planning；task_planning 且 task-plan.json 已存在 → 补全 review_progress 后进入 reviewing
```

**这意味着**：用户可以在任何时刻关闭主编排器，重新打开后它会自动从断点继续。

### 2.3 子执行器调用与故障恢复

**调用子执行器的标准流程：**

```
1. node update-state.js --expert {BATCH_ID}:{expert}:in_progress --checkpoint {BATCH_ID}-{expert}-start
2. 拉起子执行器，传入变量（见各阶段说明）
3. 等待子执行器返回结果
4. 检查结果文件是否已写入（如 .codereview/results/batch-001-core.json）
   ├─ 存在且合法 → node update-state.js --expert {BATCH_ID}:{expert}:completed --checkpoint {BATCH_ID}-{expert}-done
   └─ 不存在或异常 → 进入故障恢复
```

**故障恢复（子执行器超时/上下文超长/报错）：**

```
1. 将该专家 state 重置为 "pending"（而非 in_progress，防止死锁）
2. 写回 state.json
3. 重新拉起一个全新的子执行器实例（新上下文）
4. 最多重试 2 次；仍失败则标记 "failed"，记录到 notes[]，继续下一个专家
```

### 2.4 主编排器自身上下文保护

- 主编排器**禁止**将子执行器的提示词全文、docs/ 参考文档、专家结果 JSON 全量粘贴到主对话
- 主编排器只传递**变量名和路径**给子执行器
- 当主编排器感知到上下文接近极限时：将当前进度写入 state.json，输出「当前进度已保存，请重新启动主编排器继续」

### 2.5 多运行器并行执行约定

本 Skill 可通过 VS Code Builder、opencode 或 Claude Code 执行。主编排器应将 `prompts/*.md` 作为唯一子执行器系统提示词来源，并通过任务描述传入变量。每个子执行器的唯一交付物是写入约定的 `OUTPUT_PATH` JSON/报告文件；主编排器只检查文件，不依赖对话内容合并结果。

**并行原则：**

- Phase 3 技术栈、Phase 4 任务规划存在依赖关系，必须串行。
- Phase 5 中，同一批次内 `core`、`security`、`spring`、`data` 四个专家彼此独立，凡 `task-plan.json` 标记为适用且状态为 `pending` 的，都可以通过当前运行器的并行任务能力一次性派发。
- `failed` 是终态，主编排器不得自动重跑；仅当用户明确要求时，先人工或脚本改回 `pending`，再重新派发。
- 并行启动前，先把这些专家状态统一写为 `in_progress`；每个子执行器写自己的固定输出文件，互不共享写入目标。
- 等同批次所有适用专家完成后，先执行该批次的 `issue-curator` 做合并去重与误报排除，再运行 `resolve-report-issues.js --batch` 生成 `{BATCH_ID}-resolved.json`，最后执行 `fix-advisor`（**只读 resolved**）；fix 完成后再进入下一批次或报告合成。
- 若当前运行器不支持并行任务，则按 `core → security → spring → data` 串行降级，输出文件与状态规则保持不变。

### 2.6 `state.json` 落盘检查点（必执行）

主编排器在下列时机 **必须** 运行 `update-state.js`（成功后会打印 `{"ok":true,...}`）：

| 时机 | 命令示例 |
|------|----------|
| 启动 / Phase 0 | `node "{SKILL_ROOT}/scripts/update-state.js" --init --checkpoint phase0_init` |
| Phase 1 复述确认后 | `node .../update-state.js --branch1 {B1} --branch2 {B2} --set review_options.severity_mode=critical_high_only --set review_options.skip_low_risk_files=true --set review_options.generate_html_report=true --set review_options.max_lines_per_batch=2000 --set review_options.deep_doubt_analysis=true --set review_options.user_confirmed=true --phase diff_analysis --checkpoint phase1_done` |
| Phase 2 脚本跑完 | `node .../update-state.js --phase tech_stack --checkpoint phase2_diff_done`（可从 inventory 读 total 写入 `--set diff_analysis.total_files=N` 等） |
| Phase 3 完成 | `node .../update-state.js --phase task_planning --checkpoint phase3_tech_stack_done` |
| Phase 4 完成 | `node .../update-state.js --init-review-progress --task-plan .codereview/task-plan.json --phase reviewing --checkpoint phase4_task_plan_done` |
| 拉起子执行器**前** | `node .../update-state.js --expert {BATCH}:{expert}:in_progress --checkpoint {BATCH}-{expert}-start` |
| 子执行器**成功后** | `node .../update-state.js --expert {BATCH}:{expert}:completed --checkpoint {BATCH}-{expert}-done` |
| 并行拉起多个专家 **前** | 对每个适用专家各执行一条 `--expert ...:in_progress`，再派发 Task |
| Phase 7 MD 完成 | `node .../update-state.js --set synthesis.report_path=codereview/report_....md --set synthesis.status=completed --phase html_rendering或completed --checkpoint phase7_md_done` |
| Phase 7.5 HTML 完成/失败 | 更新 `synthesis.html_status`、`synthesis.html_report_path`、`current_phase=completed` |

**自检**：每次写 state 后，用 `read_file` 或 `cat .codereview/state.json` 确认 `updated_at` 已变为当前时间；若未变，**不得**进入下一步。

**子执行器不写 state**：只有主编排器写 `.codereview/state.json`；子执行器只写各自 `OUTPUT_PATH` / 报告文件。

---

## 3. 阶段详情

### Phase 0：初始化

```
若 .codereview/ 目录不存在 → 创建
执行（必须）：
  node "{SKILL_ROOT}/scripts/init-memory.js"
  node "{SKILL_ROOT}/scripts/update-state.js" --init --checkpoint phase0_init
确认 .codereview/state.json 已创建，current_phase = branch_selection
确认 .codereview/memory.json 已存在（空结构亦可）
```

---

### Phase 1：分支与检视选项（主编排器本地执行）

**与 §0.2 相同**（六问模板、`update-state.js` 命令、复述确认流程见 §0.2）。进入 Phase 2 条件：`review_options.user_confirmed === true`。

**字段说明（写入 `review_options`）：**

| 字段 | 取值 |
|------|------|
| `severity_mode` | `all` \| `critical_high_only` |
| `skip_low_risk_files` | `true` \| `false` |
| `generate_html_report` | `true` \| `false`；默认 `true` |
| `max_lines_per_batch` | 正整数，默认 `2000`（Phase 2 传给 `batch-processor.js --max-lines`） |
| `deep_doubt_analysis` | `true` \| `false`；默认 `true`，允许专家/策展对疑问代码读取所属源文件局部窗口或有界下钻，并对问题行调用的存量函数做关联下钻复核（避免「调用了已处理的存量函数」被误报） |
| `user_confirmed` | Phase 1 复述确认后为 `true` |

---

### Phase 2：变动文件与分批（主编排器 + 脚本）

**进入本阶段前自检：** `review_options.user_confirmed === true`。若为 `false`，**立即退回 Phase 1**，不得执行下方脚本。

**Step 1：生成清单**（若 `review_options.skip_low_risk_files === true`，追加 `--skip-low-risk true`）
```text
node "{SKILL_ROOT}/scripts/get-diff-files.js" --branch1 {BRANCH1} --branch2 {BRANCH2} --output .codereview/file-inventory.json
```

默认 `--update-mode local-ff`：脚本会 fetch upstream/origin，并只用 fast-forward 更新本地 `BRANCH1`、`BRANCH2`。若更新失败，**立即停止**，不要用可能过期的本地分支继续检视；向用户确认二选一：手动更新本地两个分支后重新开始，或重新运行并追加 `--update-mode remote` 直接对比远端分支。用户确认已手动更新时，可追加 `--update-mode local`。

**Step 2：分批**（`max-lines` 取自 `state.review_options.max_lines_per_batch`，默认 2000）
```text
node "{SKILL_ROOT}/scripts/batch-processor.js" --inventory .codereview/file-inventory.json --max-lines {MAX_LINES} --output .codereview/file-inventory.json
```

**Step 3：预计算批次 diff（默认执行）**

多专家各自反复 `git diff` 会重复 I/O，且 diff 文本可能不一致。**每批次只对 Git 调用一次**，将 unified diff 写入 `.codereview/diffs/{BATCH_ID}.patch`，子执行器**优先读该文件**，与多次单文件 diff 等价，上下文更稳定。

```text
node "{SKILL_ROOT}/scripts/export-batch-diffs.js" --inventory .codereview/file-inventory.json --output-dir .codereview/diffs
```

脚本会更新 `file-inventory.json` 的 `diff_bundle`（含 `manifest.json`）。单文件变更超过 `max_lines_per_batch` 时，exporter 会按实际 `+/-` 变更行自动拆成多个 patch，并把 `diff_slice` 与 branch1/new-side `line_ranges` 写回批次；替换块的删除/新增保持配对，重跑 exporter 会复用原批次 ID 和切片边界。后续规划、检视、curator、resolver 必须保留并遵守该硬边界。`git diff` 执行失败必须停止，不得生成空 manifest；只有命令成功但某 patch 为空时，主编排器才可按 `file-inventory.json.git_refs` 补取单文件 diff。

**Step 4：** 向用户展示批次数、文件数、行数及跳过低风险统计（若有），确认后执行：

```text
node "{SKILL_ROOT}/scripts/update-state.js" --phase tech_stack --checkpoint phase2_done
```

（可选：从 `file-inventory.json` 读取统计后 `--set diff_analysis.total_files=...` 等。）

---

### Phase 3：技术栈分析

**拉起子执行器：** `java-codereview-tech-stack`
**提示词文件：** `{SKILL_ROOT}/prompts/tech-stack-analysis.md`

**传入变量：**
| 变量 | 值 |
|------|---|
| `PROJECT_ROOT` | 项目仓库根目录 |
| `OUTPUT_PATH` | `.codereview/tech-stack.json` |

**完成标志：** `.codereview/tech-stack.json` 文件存在且 JSON 合法

**完成后：**

```text
node "{SKILL_ROOT}/scripts/update-state.js" --phase task_planning --checkpoint phase3_done
```

---

### Phase 4：任务规划

**拉起子执行器：** `java-codereview-task-plan`
**提示词文件：** `{SKILL_ROOT}/prompts/task-planner.md`

**传入变量：**
| 变量 | 值 |
|------|---|
| `INVENTORY_PATH` | `.codereview/file-inventory.json` |
| `TECH_STACK_PATH` | `.codereview/tech-stack.json` |
| `OUTPUT_PATH` | `.codereview/task-plan.json` |

**完成标志：** `.codereview/task-plan.json` 文件存在

**完成后：**

```text
node "{SKILL_ROOT}/scripts/update-state.js" --init-review-progress --task-plan .codereview/task-plan.json --phase reviewing --checkpoint phase4_done
```

---

### Phase 5：多专家检视（循环：批次 × 专家）

**核心循环逻辑：**

```
读取 state.json 的 review_progress
遍历所有批次（batch-001, batch-002, ...）：
  遍历该批次的专家（core → security → spring → data）：
    if status == "completed" or "skipped" → 跳过
    if status == "pending"               → 执行该专家
    if status == "failed"                → 跳过（终态；除非用户要求改回 pending）
    执行完成 → 立即写回 state.json
  该批次 4 位检视专家全部 completed/skipped 后：
    执行 issue-curator（Phase 5.5 单批，跨专家合并 + 函数体级误报排除）
    仅当 curator 正式 JSON 完整时运行单批 resolver
    resolver 成功后 curator 状态设 completed → 写回 state.json
  curator + resolver 完成后：
    执行 fix-advisor（Phase 6 单批，输入为 batch resolved JSON）
    fix 状态设 completed → 写回 state.json

所有批次全部完成 → current_phase = "synthesizing"
```

**每个专家的子执行器调用：**

**拉起前（必做）** — 生成项目记忆 brief：

```text
node "{SKILL_ROOT}/scripts/build-memory-context.js" --memory .codereview/memory.json --batch-id {BATCH_ID} --expert {core|spring|security|data} --output .codereview/memory-brief-{BATCH_ID}-{expert}.json
```

| 专家 | 子执行器标识 | 提示词文件 | 输出文件 |
|------|----------------|------------|---------|
| core | `java-codereview-review-core` | `{SKILL_ROOT}/prompts/code-scanner.md` | `.codereview/results/{BATCH_ID}-core.json` |
| security | `java-codereview-review-security` | `{SKILL_ROOT}/prompts/security-reviewer.md` | `...-security.json` |
| spring | `java-codereview-review-spring` | `{SKILL_ROOT}/prompts/framework-reviewer.md` | `...-spring.json` |
| data | `java-codereview-review-data` | `{SKILL_ROOT}/prompts/perf-reviewer.md` | `...-data.json` |

**统一传入变量（每次拉起子执行器必传）：**

| 变量 | 值 |
|------|---|
| `BATCH_ID` | 如 `batch-001` |
| `BATCH_FILES` | 该批次文件列表 JSON（从 task-plan.json 读取） |
| `BRANCH1` | 被检视分支 |
| `BRANCH2` | 基准分支 |
| `DIFF_BRANCH1` | 实际用于 diff 的被检视 ref：读取 `.codereview/file-inventory.json.git_refs.branch1.diff_ref`；缺失时才退回 `BRANCH1` |
| `DIFF_BRANCH2` | 实际用于 diff 的基准 ref：读取 `.codereview/file-inventory.json.git_refs.branch2.diff_ref`；缺失时才退回 `BRANCH2` |
| `DIFF_PATCH_PATH` | `.codereview/diffs/{BATCH_ID}.patch`（Phase 2 已导出则必传；不存在则子执行器仅用 git） |
| `SEVERITY_MODE` | `state.json` → `review_options.severity_mode`（`all` 或 `critical_high_only`） |
| `DEEP_DOUBT_ANALYSIS` | `state.json` → `review_options.deep_doubt_analysis` |
| `MEMORY_BRIEF_PATH` | `.codereview/memory-brief-{BATCH_ID}-{expert}.json`（Phase 5 拉起前由 `build-memory-context.js` 生成） |
| `TECH_STACK` | tech-stack.json 内容摘要（或路径，让子执行器自读） |
| `OUTPUT_PATH` | 结果文件路径 |
| `SKILL_ROOT` | 本 Skill 根目录（子执行器需读取 docs/ 下参考文档） |

**检视范围（硬性规则，传达给每个子执行器）：**

> **优先**读取 `DIFF_PATCH_PATH` 中的 unified diff。缺失或为空时，主编排器必须从 `.codereview/file-inventory.json.git_refs` 取 `branch2.diff_ref` 与 `branch1.diff_ref`，分别作为 `DIFF_BRANCH2` / `DIFF_BRANCH1` 后再按文件补取 diff。
> 只检视变更行；禁止对未改动代码批量报问题。`line` 字段必须为字符串；每条 issue 必须补充 `symbol`（如 `UserServiceImpl#createOrder`、`UserMapper.xml#selectById`），报告不得只依赖行号定位。
> 若 `BATCH_FILES` 文件条目含 `line_ranges`，问题起始行必须落在其中一个闭区间内。patch 的少量越界上下文仅供理解，禁止对范围外变更报问题；fallback 取得整文件 diff 后也必须按该范围过滤。
>
> 若 `SEVERITY_MODE` 为 `critical_high_only`，**仅**输出 `critical` 与 `high`，不得输出 `medium` / `low`。
>
> 若 diff 仅新增字段、局部变量、函数/方法、Mapper 方法、Controller 接口、Bean、配置键等符号，且 patch 内无调用/引用/绑定，必须确认是否合理；`DEEP_DOUBT_ANALYSIS=true` 时允许读取所属源文件局部窗口或对符号做一次有界引用搜索（最多读取 50 条匹配，结果过多即停止）。无法证明合理时输出需确认 issue（`critical_high_only` 下用 `high`）。

**并行派发建议：**

同一 `BATCH_ID` 中，对 `applicable_experts` 取交集后可一次性并行拉起多个子执行器。每个任务必须显式包含：`BATCH_ID`、`BATCH_FILES`、`BRANCH1`、`BRANCH2`、`DIFF_BRANCH1`、`DIFF_BRANCH2`、`DIFF_PATCH_PATH`、`SEVERITY_MODE`、`DEEP_DOUBT_ANALYSIS`、`MEMORY_BRIEF_PATH`、`TECH_STACK`、`SKILL_ROOT`、独立 `OUTPUT_PATH`，并强调“完成后只写对应输出文件”。主编排器等待这一组输出文件全部存在且 JSON 合法后，再将对应状态改为 `completed`；随后串行执行 `issue-curator` → `resolve-report-issues.js --batch` → `fix-advisor`。

**适用性剪枝（来自 task-plan.json 的 `applicable_experts`）：**

- 若 `review_options.skip_low_risk_files` 为 `true`，DTO/Entity/测试类已在 Phase 2 排除，不会出现在批次中
- 若为 `false`：纯 POJO/DTO/Entity 批次 → 跳过 spring、data
- 纯 Mapper XML → 重点 data + core
- Controller → security + spring 重点
- Service → spring + data 重点

---

### Phase 5.5：问题策展（每批次一次，嵌入 Phase 5 循环；4 专家完成后执行）

**拉起子执行器：** `java-codereview-issue-curator`
**提示词文件：** `{SKILL_ROOT}/prompts/issue-curator.md`

**拉起前（必做）：**

```text
node "{SKILL_ROOT}/scripts/build-memory-context.js" --memory .codereview/memory.json --batch-id {BATCH_ID} --expert curator --output .codereview/memory-brief-{BATCH_ID}-curator.json
```

**目的：**
1. **跨专家合并**：把同一文件、同一行（区间重叠）、实质相同根因的多条 issue 合并为一条主条目（按主责专家优先级），其余视角并入 `merged_from[]`，避免 fix-advisor 与最终报告对同一行写出多段重复内容
2. **函数体级关联复核**：对合并后剩余的每条 issue，先在其所在函数体（或 XML SQL 节点）范围内检查是否已通过判空 / try-with-resources / `@Valid` / 工具断言 / 白名单 / 同步原语等手段处理；已处理的移入 `invalidated[]` 不再下发，避免误报
3. **被调用关联函数下钻复核**：当 NPE / 资源 / 参数校验 / 异常类 issue 的安全性取决于问题行之前调用的**存量函数**（例如先 `validateUser(user)` 再 `user.getName()`）时，在 `deep_doubt_analysis` 为 true 且预算内（每批下钻 ≤ 3 次）下钻该被调用函数体，确认其确实已处理后才判为误报，从而做到「关联代码检查而非只看变更行」

**传入变量：**
| 变量 | 值 |
|------|---|
| `BATCH_ID` | 当前批次 |
| `BATCH_FILES` | 当前批次文件列表 |
| `BRANCH1` / `BRANCH2` | 同 Phase 5 |
| `DIFF_BRANCH1` / `DIFF_BRANCH2` | 同 Phase 5；用于 curator 的 `git show` / 兜底 diff，避免 remote 模式回退到过期本地分支 |
| `DIFF_PATCH_PATH` | `.codereview/diffs/{BATCH_ID}.patch`（与 Phase 5 共用） |
| `SEVERITY_MODE` | 同 Phase 5（`critical_high_only` 时不得保留 medium / low） |
| `DEEP_DOUBT_ANALYSIS` | 同 Phase 5 |
| `MEMORY_BRIEF_PATH` | `.codereview/memory-brief-{BATCH_ID}-curator.json` |
| `RESULTS_DIR` | `.codereview/results/`（用于读取 4 份原始专家 JSON） |
| `OUTPUT_PATH` | `.codereview/results/{BATCH_ID}-curated.json` |
| `SKILL_ROOT` | 本 Skill 根目录 |

**完成标志：** `{BATCH_ID}-curated.json` 为完整原子输出且 JSON 合法（含 `summary` / `issues[]` / `invalidated[]` 三个字段）；仅存在 `.partial` 时不得标记 completed

**证据解析门禁（curator 完成后必做）：**

```text
node "{SKILL_ROOT}/scripts/resolve-report-issues.js" --state .codereview/state.json --inventory .codereview/file-inventory.json --results .codereview/results --batch {BATCH_ID} --output .codereview/results/{BATCH_ID}-resolved.json --discarded-output .codereview/discarded-issues.json
```

fix-advisor 只读取 `{BATCH_ID}-resolved.json`；无法恢复定位/描述/代码的候选被忽略并记录到诊断文件。

---

### Phase 6：修复建议（每批次一次，嵌入 Phase 5 循环中）

**拉起子执行器：** `java-codereview-fix-advisor`
**提示词文件：** `{SKILL_ROOT}/prompts/fix-advisor.md`

**传入变量：**
| 变量 | 值 |
|------|---|
| `BATCH_ID` | 当前批次 |
| `BATCH_FILES` | 当前批次文件列表 |
| `BRANCH1` | 被检视分支（与 Phase 5 相同） |
| `BRANCH2` | 基准分支（与 Phase 5 相同） |
| `DIFF_BRANCH1` | 实际用于 diff 的被检视 ref（与 Phase 5 相同） |
| `DIFF_BRANCH2` | 实际用于 diff 的基准 ref（与 Phase 5 相同） |
| `DIFF_PATCH_PATH` | `.codereview/diffs/{BATCH_ID}.patch`（Phase 2 `export-batch-diffs.js` 已生成；主编排器按 `BATCH_ID` 自动拼装路径并传入，**用户无需填写**；与检视专家共用同一份 unified diff） |
| `CURATED_PATH` | `.codereview/results/{BATCH_ID}-resolved.json`（证据解析后的唯一输入） |
| `RESULTS_DIR` | `.codereview/results/` |
| `SEVERITY_MODE` | 同 Phase 5（`critical_high_only` 时仅对 C/H 问题给修复建议） |
| `OUTPUT_PATH` | `.codereview/results/{BATCH_ID}-fix.json` |

**修复阶段上下文规则（须传达给子执行器）：** 优先从 `DIFF_PATCH_PATH` 中定位各 `issue` 对应文件与行号附近的 hunk，用 patch 内已有上下文生成修复片段；**禁止**对同一工作区源文件反复 `read_file`。仅当 patch 缺失、为空或 hunk 上下文不足以写出正确补丁时，对该文件**最多**使用一次工作区读取；如需补取 diff，必须使用 `.codereview/file-inventory.json.git_refs` 中的 `branch2.diff_ref...branch1.diff_ref`。

---

### Phase 7：报告合成

**Phase 7 开始前必做：**

```text
node "{SKILL_ROOT}/scripts/resolve-report-issues.js" --state .codereview/state.json --inventory .codereview/file-inventory.json --results .codereview/results --output .codereview/resolved-issues.json --discarded-output .codereview/discarded-issues.json
node "{SKILL_ROOT}/scripts/git-line-authors.js" --inventory .codereview/file-inventory.json --issues .codereview/resolved-issues.json --output .codereview/line-authors.json
```

**Step 1（必做，优先）：** 机械合成 MD，避免问题多时把所有 JSON 压入模型上下文，也保证第六节问题清单由结构化 issue 全量生成：

```text
node "{SKILL_ROOT}/scripts/render-report-md.js" --state ".codereview/state.json" --results ".codereview/results" --issues ".codereview/resolved-issues.json" --inventory ".codereview/file-inventory.json" --tech-stack ".codereview/tech-stack.json" --template "{SKILL_ROOT}/templates/report-template.md" --out-dir "codereview"
```

脚本 stdout `ok: true`、`unresolvedPlaceholders: []`、`section6IssueRowsComplete: true` 才算完成；同时记录 `discardedIssueCount` / `incompleteIssues` / `missingCodeIssues`，被忽略候选不得进入统计、第五章或第六章。

**Step 2（仅 Step 1 失败）：** 拉起子执行器 `java-codereview-report-synthesizer`（`{SKILL_ROOT}/prompts/report-synthesizer.md`）作为兜底，禁止省略第六节问题行。

**传入变量：**
| 变量 | 值 |
|------|---|
| `STATE_PATH` | `.codereview/state.json` |
| `RESULTS_DIR` | `.codereview/results/` |
| `TECH_STACK_PATH` | `.codereview/tech-stack.json` |
| `INVENTORY_PATH` | `.codereview/file-inventory.json` |
| `DIFF_PATCH_DIR` | `.codereview/diffs` |
| `TEMPLATE_PATH` | `{SKILL_ROOT}/templates/report-template.md` |
| `REPORT_PATH` | 取脚本 stdout 的 `report`；默认自动生成 `codereview/report_{REPO_NAME}_{BRANCH1}_{DATE}.md` |

合成官须读取 `state.json` 的 `review_options` 与 `file-inventory.json` 的 `review_scope`，填入报告基本信息（检视深度、是否跳过低风险及跳过文件数）。

提交人只使用 resolved 定位对应的 `line_authors["文件:起始行"]`；禁止通过全局 issue ID 猜测作者。

**完成后：**

1. 写入 `synthesis.report_path = REPORT_PATH`，`synthesis.status = "completed"`
2. 若 `review_options.generate_html_report === true`：
   - `synthesis.html_status = "pending"`
   - `synthesis.html_report_path =` 与 MD 同路径，扩展名改为 `.html`
   - `current_phase = "html_rendering"` → 进入 Phase 7.5
3. 否则：
   - `synthesis.html_status = "skipped"`
   - `current_phase = "completed"` → 按下文「completed 输出文案」`skipped` 模板告知用户

---

### Phase 7.5：HTML 报告渲染（可选，仅 `generate_html_report === true`）

**前置条件：** Phase 7 的 MD 报告已存在且非空。

**Step 1（必做，优先于子执行器）：** 在业务仓库根目录执行机械渲染（将 MD 全文填入 HTML 各章节，**禁止**「请查看同名 .md」类占位）：

```text
node "{SKILL_ROOT}/scripts/render-report-html.js" --md "{REPORT_MD_PATH}" --shell "{SKILL_ROOT}/templates/report-shell.html" --out "{HTML_REPORT_PATH}" --state ".codereview/state.json"
```

| 变量 | 值 |
|------|-----|
| `REPORT_MD_PATH` | `synthesis.report_path` |
| `HTML_TEMPLATE_PATH` | `{SKILL_ROOT}/templates/report-shell.html` |
| `HTML_REPORT_PATH` | 与 MD 同名 `.html`（`/` → `_`） |

脚本 stdout 为 JSON：`ok: true`、`placeholdersOk: true`、`section6IssueRowsComplete: true`、`sectionIssueIdsMatch: true`、`incompleteIssues: []` 表示写出成功。若任一项失败，回到 resolver/Phase 7 重建 MD；HTML 不自行制造缺失定位或代码。

**Step 2（主编排校验，五项缺一不可）：**

1. 文件首部含 `<!DOCTYPE html>`
2. 文件末尾 16KB 内含 `</html>`
3. 文件末尾 16KB 内含 `<!-- ato-codereview-html-end -->`
4. stdout `allIssueCodeMissing === false`
5. stdout `section6IssueRowsComplete === true`
6. stdout `sectionIssueIdsMatch === true` 且 `incompleteIssues` 为空

**Step 3（仅当 Step 1/2 失败时）：** 拉起子执行器 `java-codereview-report-html`（`prompts/report-html.md`），传入 `REPORT_MD_PATH`、`HTML_TEMPLATE_PATH`、`HTML_REPORT_PATH`；**禁止**使用 Step 4 降级占位，须从 MD 机械转换全文。最多 2 次；仍失败 → `synthesis.html_status = "failed"`，记录 `notes[]`，`current_phase = "completed"`（**MD 仍交付**）。

**完成后：** `synthesis.html_status = "completed"`，`current_phase = "completed"`，按下文「completed 输出文案」输出。

**HTML 签收：** 第六节勾选有效/已修（勾选「已修复」自动勾选「有效」）；第七节验证与签收：开发负责人填写结论并提交，**备注**默认「上述问题无需修复」可修改；自动汇总「本次参与开发」。提交后回写同名 MD 并生成 `【Fix】` 前缀 HTML；若浏览器无法 fetch MD（如 `file://`），壳内 JS 会根据当前页面直接生成完整 MD。

### completed 输出文案（主编排器必须严格使用）

在 `current_phase = "completed"` 时，根据 `synthesis.html_status` 选择**其一**（随后均追加问题统计摘要：Critical/High/Medium/Low 数量、必改项条数、1–3 条重点关注）：

| `html_status` | 输出模板 |
|---|---|
| `skipped` | `检视完成。MD 报告：{report_path}` |
| `completed` | `检视完成。MD 报告：{report_path}；HTML 报告：{html_report_path}` |
| `failed` | `检视完成。MD 报告：{report_path}；HTML 渲染已重试 2 次仍失败，已跳过（详见 state.notes），不影响 MD 交付` |

---

## 4. 子执行器标识对照表

VS Code 子 Builder、opencode subagent、Claude Code subagent/Task 均使用同一套标识和同一套提示词。系统提示词取自 `{SKILL_ROOT}/prompts/` 对应文件：

| 标识 | 提示词来源 | Phase |
|------|-----------|-------|
| `java-codereview-tech-stack` | `prompts/tech-stack-analysis.md` | 3 |
| `java-codereview-task-plan` | `prompts/task-planner.md` | 4 |
| `java-codereview-review-core` | `prompts/code-scanner.md` | 5 |
| `java-codereview-review-spring` | `prompts/framework-reviewer.md` | 5 |
| `java-codereview-review-security` | `prompts/security-reviewer.md` | 5 |
| `java-codereview-review-data` | `prompts/perf-reviewer.md` | 5 |
| `java-codereview-issue-curator` | `prompts/issue-curator.md` | 5.5 |
| `java-codereview-fix-advisor` | `prompts/fix-advisor.md` | 6 |
| `java-codereview-report-synthesizer` | `prompts/report-synthesizer.md` | 7 |
| `java-codereview-report-html` | `prompts/report-html.md` | 7.5（可选） |

新流程仅保留上表 10 个子执行器标识（HTML 子执行器可选）。

---

## 5. 运行器接入

- **VS Code Builder**：主 Builder 系统提示词使用 `{SKILL_ROOT}/vscode-main-builder.md`；10 个子 Builder 使用上表 `prompts/*.md`。Phase 5 同批专家可并行，`issue-curator` → `resolve-report-issues` → `fix-advisor` → 报告合成串行。
- **opencode**：使用 `{SKILL_ROOT}/opencode/opencode.example.json`；主 agent prompt 指向 `SKILL.md`，subagent prompt 指向同一套 `prompts/*.md`。
- **Claude Code**：主会话读取 `SKILL.md`；需要并行时用 Claude Code 的 subagent/Task 能力分别加载上表 `prompts/*.md`，每个任务传入 Phase 5 变量并只写自己的 `OUTPUT_PATH`。

---

## 6. Git 命令备忘

```text
git rev-parse --verify "branch-name"
git --no-pager diff --name-only DIFF_BRANCH2...DIFF_BRANCH1
git --no-pager diff DIFF_BRANCH2...DIFF_BRANCH1 -- path/to/File.java
git --no-pager diff --stat DIFF_BRANCH2...DIFF_BRANCH1
```

---

## 7. 主编排器禁令（防上下文爆炸）

1. **不要**将 `prompts/*.md` 的内容读入主对话
2. **不要**将 `docs/*.md` 参考文档全文读入主对话（留给子执行器自读）
3. **不要**将专家结果 JSON 全文读入主对话（只在需要验证时读几行确认文件存在与格式）
4. **不要**在主对话中做代码检视（那是子执行器的事）
5. 如果感知到上下文接近极限 → 立刻写 state.json → 告知用户重启
