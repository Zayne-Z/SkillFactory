#!/usr/bin/env node
/**
 * 获取两个分支之间的 Java 项目变动文件清单
 * 用法：node get-diff-files.js --branch1 <branch1> --branch2 <branch2> --output <output.json>
 *
 * 输出 JSON 格式：
 * {
 *   "branch1": "feature/user-service",
 *   "branch2": "master",
 *   "generated_at": "2026-04-06T10:00:00.000Z",
 *   "total_files": 18,
 *   "total_changed_lines": 1560,
 *   "files": [
 *     {
 *       "path": "src/main/java/com/example/service/impl/UserServiceImpl.java",
 *       "type": "service",
 *       "status": "M",
 *       "additions": 85,
 *       "deletions": 30,
 *       "changed_lines": 115,
 *       "size_bytes": 6200
 *     }
 *   ]
 * }
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

function parseArgs(args) {
  const result = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2);
      result[key] = args[i + 1] || true;
      i++;
    }
  }
  return result;
}

// 识别 Java 文件类型（用于任务规划专家的优先级判断）
function getJavaFileType(filePath) {
  const basename = path.basename(filePath, '.java');
  const lowerPath = filePath.toLowerCase();
  const lowerBase = basename.toLowerCase();

  // 按后缀名分类（非 .java 文件）
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.xml') {
    if (lowerPath.includes('mapper') || lowerPath.includes('dao')) return 'mapper-xml';
    if (lowerBase === 'pom') return 'build';
    return 'config-xml';
  }
  if (ext === '.yml' || ext === '.yaml') return 'config-yaml';
  if (ext === '.properties') return 'config-properties';
  if (ext === '.gradle') return 'build';
  if (ext === '.sql') return 'sql';

  // Java 类文件分类
  if (!ext || ext === '.java') {
    if (lowerBase.endsWith('controller')) return 'controller';
    if (lowerBase.endsWith('restcontroller')) return 'controller';
    if (lowerBase.endsWith('serviceimpl')) return 'service-impl';
    if (lowerBase.endsWith('service') && !lowerBase.endsWith('serviceimpl')) {
      // 接口 vs 实现：实际内容判断较难，通过路径区分
      if (lowerPath.includes('/impl/')) return 'service-impl';
      return 'service-interface';
    }
    if (lowerBase.endsWith('mapper') || lowerBase.endsWith('dao') || lowerBase.endsWith('repository')) return 'mapper';
    if (lowerBase.endsWith('entity') || lowerBase.endsWith('do') || lowerBase.endsWith('po')) return 'entity';
    if (lowerBase.endsWith('vo') || lowerBase.endsWith('dto') || lowerBase.endsWith('request') || lowerBase.endsWith('response')) return 'dto';
    if (lowerBase.endsWith('config') || lowerBase.endsWith('configuration')) return 'config-java';
    if (lowerBase.endsWith('util') || lowerBase.endsWith('utils') || lowerBase.endsWith('helper')) return 'util';
    if (lowerBase.endsWith('test')) return 'test';
    if (lowerBase.endsWith('enum') || lowerBase.endsWith('enums')) return 'enum';
    if (lowerBase.endsWith('exception')) return 'exception';
    if (lowerBase.endsWith('handler') || lowerBase.endsWith('advice')) return 'handler';
    if (lowerBase.endsWith('interceptor') || lowerBase.endsWith('filter')) return 'interceptor';
  }

  return 'java-other';
}

// 判断是否为需要检视的文件（过滤无关文件）
function isReviewableFile(filePath) {
  const ignoredPaths = [
    'node_modules/', '.git/', 'target/', 'build/', 'out/',
    '.mvn/', '.gradle/', '__pycache__/', '.idea/', '.vscode/',
    'test-output/', 'generated-sources/',
  ];
  if (ignoredPaths.some(p => filePath.includes(p))) return false;

  // 过滤生成的 MapStruct 实现类
  if (filePath.includes('/generated/') || path.basename(filePath).includes('MapperImpl')) return false;

  const reviewableExts = [
    '.java', '.xml', '.yml', '.yaml', '.properties',
    '.gradle', '.sql', '.json',
  ];
  const ext = path.extname(filePath).toLowerCase();

  // pom.xml 是构建文件，需要检视
  const basename = path.basename(filePath);
  if (basename === 'pom.xml' || basename === 'build.gradle' || basename === 'build.gradle.kts') return true;

  return reviewableExts.includes(ext);
}

function getFileSize(filePath) {
  try {
    const stat = fs.statSync(filePath);
    return stat.size;
  } catch {
    return 0;
  }
}

function exec(cmd) {
  try {
    return execSync(cmd, {
      encoding: 'utf8',
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, GIT_PAGER: 'cat', GIT_TERMINAL_PROMPT: '0' },
    }).trim();
  } catch {
    return '';
  }
}

function ensureDir(dirPath) {
  if (dirPath && !fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function main() {
  const args = parseArgs(process.argv.slice(2));

  if (!args.branch1 || !args.branch2) {
    console.error('用法: node get-diff-files.js --branch1 <branch1> --branch2 <branch2> --output <output.json>');
    process.exit(1);
  }

  const { branch1, branch2, output } = args;
  const outputPath = output || '.codereview/file-inventory.json';

  console.log(`正在分析分支差异: ${branch1} vs ${branch2} ...`);

  // 验证分支存在（不使用 2>/dev/null，exec 已将 stderr 管道化，跨平台兼容）
  const b1Exists = exec(`git rev-parse --verify "${branch1}"`);
  const b2Exists = exec(`git rev-parse --verify "${branch2}"`);

  if (!b1Exists) {
    console.error(`错误：分支 "${branch1}" 不存在`);
    process.exit(1);
  }
  if (!b2Exists) {
    console.error(`错误：分支 "${branch2}" 不存在`);
    process.exit(1);
  }

  // 获取变动文件列表（含状态）
  const diffNameStatus = exec(`git diff --name-status "${branch2}"..."${branch1}"`);
  if (!diffNameStatus) {
    console.log('两个分支之间没有差异。');
    const emptyResult = {
      branch1, branch2,
      generated_at: new Date().toISOString(),
      total_files: 0,
      total_changed_lines: 0,
      files: []
    };
    ensureDir(path.dirname(outputPath));
    fs.writeFileSync(outputPath, JSON.stringify(emptyResult, null, 2), 'utf8');
    console.log(`已写入: ${outputPath}`);
    return;
  }

  // 获取变动统计
  const diffNumStat = exec(`git diff --numstat "${branch2}"..."${branch1}"`);

  // 解析 numstat
  const numStatMap = {};
  diffNumStat.split('\n').forEach(line => {
    const parts = line.split('\t');
    if (parts.length >= 3) {
      const filePath = parts[2].trim();
      const additions = parseInt(parts[0]) || 0;
      const deletions = parseInt(parts[1]) || 0;
      numStatMap[filePath] = { additions, deletions };
    }
  });

  // 解析文件列表
  const files = [];
  let totalChangedLines = 0;

  diffNameStatus.split('\n').forEach(line => {
    if (!line.trim()) return;
    const parts = line.split('\t');
    const status = parts[0].trim();
    let filePath = parts[parts.length - 1].trim();

    if (status.startsWith('R') || status.startsWith('C')) {
      filePath = parts[2].trim();
    }

    if (!isReviewableFile(filePath)) return;
    if (status === 'D') return; // 跳过删除文件

    const stats = numStatMap[filePath] || { additions: 0, deletions: 0 };
    const changedLines = stats.additions + stats.deletions;
    totalChangedLines += changedLines;

    files.push({
      path: filePath,
      type: getJavaFileType(filePath),
      status: status.charAt(0),
      additions: stats.additions,
      deletions: stats.deletions,
      changed_lines: changedLines,
      size_bytes: getFileSize(filePath),
    });
  });

  // 按变动行数降序
  files.sort((a, b) => b.changed_lines - a.changed_lines);

  const result = {
    branch1,
    branch2,
    generated_at: new Date().toISOString(),
    total_files: files.length,
    total_changed_lines: totalChangedLines,
    files,
  };

  ensureDir(path.dirname(outputPath));
  fs.writeFileSync(outputPath, JSON.stringify(result, null, 2), 'utf8');

  console.log(`\n变动文件分析完成：`);
  console.log(`  文件总数: ${files.length}`);
  console.log(`  变动总行数: ${totalChangedLines}`);

  // 按类型统计
  const typeStat = {};
  files.forEach(f => { typeStat[f.type] = (typeStat[f.type] || 0) + 1; });
  Object.entries(typeStat).sort((a, b) => b[1] - a[1]).forEach(([type, count]) => {
    console.log(`  ${type}: ${count} 个文件`);
  });

  console.log(`  输出: ${outputPath}`);
}

main();
